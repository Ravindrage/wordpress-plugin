<?php

/**
 * Fired during plugin activation
 *
 * @link       http://localhost
 * @since      1.0.0
 *
 * @package    Appfoster
 * @subpackage Appfoster/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Appfoster
 * @subpackage Appfoster/includes
 * @author     Ravindra Gehlot <localhost@gmail.com>
 */
class Appfoster_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
